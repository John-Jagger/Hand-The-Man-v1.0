
import java.util.List;
import java.util.ArrayList;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.Random;
import java.util.Scanner;
/**
 * Write a description of class Hang The Man here.
 *
 * @author John Jagger
 * @version ver. 1.0.0
 */
public class HangTheMan
{
    public static String[][] word1 = new String [1][3];
    public static String[][] word2 = new String [1][7];
    public static String blank = " - ";
    public static int hp = 0;
    public static String underline = "";
    public static void main(String[] args) throws InterruptedException
    {
        int mode;

        System.out.println("");
        System.out.print("Powering on . . . ");
        delayDots(1);
        delayDots(1);
        System.out.println("!! ⒿⓞⓗⓝⓉⓔⓝⓓⓞ !!");
        delayDots(1);

        System.out.println("========  山 乇 ㄥ 匚 ㄖ 爪 乇  ========");
        System.out.println("=                 TO                =");
        System.out.println("=            HANG THE MAN           =");
        System.out.println("=                 💀                =");
        System.out.println("=====================================");
        System.out.println("=         -+- Choose Mode -+-       =");
        System.out.println("=           🎉 party mode 🎉         = ");
        System.out.println("=  -+-         eneter '2'      -+-  =");
        System.out.println("=====================================");
        System.out.println("= No man was harmed in the making   =");
        System.out.println("=            of this gme            =");
        System.out.println("=====================================");
        System.out.println("=       ALL RIGHTS RESERVED TO      =");
        System.out.println("=          ⒿⓞⓗⓝⓉⓔⓝⓓⓞ          =");
        System.out.println("=====================================");

        Scanner user_input = new Scanner(System.in);
        mode = user_input.nextInt();

        if(mode == 2)
        {
            prolouge();
            partyMode();
        }
    }

    public static void partyMode() throws InterruptedException
    {
        clearScreen();
        party();
        Scanner in = new Scanner(System.in);
        String wordM = in.nextLine();
        clearScreen();
        hangman2();
        wordM = wordM.toLowerCase();
        char[] ch = wordM.toCharArray();
        for (int i = 0; i< wordM.length(); i++)
        {
            if(wordM.charAt(i) == ' ')
            {
                underline += " ";
            }
            else             
            {
                underline += "_";
            }
        }
        System.out.println(underline);

        char[] answer = underline.toCharArray();
        
        while (underscoreCheck(answer))
        {
            String guess1 = in.next().toLowerCase();
            char guess = guess1.charAt(0);
            boolean right = false;
            //String guess = in.next();

            for (int i = 0; i< wordM.length(); i++)
            {
                if(wordM.charAt(i) == guess)
                {
                    clearScreen();
                    System.out.println("Congrates " + guess + " was a correct letter, but can you guess the next one?");
                    answer[i] = guess;
                    right = true;
                }
            }
            if (right == false)
            {
                clearScreen();
                hp++;
                System.out.println("The letter " + guess + " is not arpart of the chosen word, try again.");
            }
            if ( hp == 6)
            {
                clearScreen();
                hangman2();
                grave();
                System.out.println("You have failed your mission, and Dave");
                System.out.println("the gardener is dead, wow");
                System.out.println("The word was " + wordM);
                break;
            }
            hangman2();
            System.out.println(answer);
        }
    }

    
    
    public static boolean underscoreCheck(char[] u)
    {
        for(char c : u)
        {
            if (c == '_')
            {
                return true;
            }
        }
        return false;
    }

    public static void delayDots(int dotAmount) throws InterruptedException
    {
        for(int i=0; i<dotAmount; i++)
        {
            TimeUnit.SECONDS.sleep(1);
            System.out.print("");
        }
        System.out.println();
    }

    public static void delayDots() throws InterruptedException
    {
        delayDots(0);
    }

    public static void clearScreen()
    {
        System.out.print('\u000C');
    }

    public static void party()
    {
        System.out.println("========  卩卂尺ㄒㄚ  爪ㄖり乇  ========");
        System.out.println("=  -     PLAYER 1 / GARMADAN      - =");
        System.out.println("=  +     ENTER A WORD/PHRASE      + =");
        System.out.println("=  -              💀              - =");
        System.out.println("=  +       TO TEST PLAYER 2       + =");
        System.out.println("=====================================");
    }

    public static void hangman2()
    {

        if (hp == 0) {
            System.out.println("   ____________");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("___|___");
            System.out.println("|     | ");
            System.out.println("=====================================");
        }
        if (hp == 1) {
            System.out.println("   ____________");
            System.out.println("   |          _|_");
            System.out.println("   |         /   \\");
            System.out.println("   |        | * * |");
            System.out.println("   |         \\_ _/");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("___|___");
            System.out.println("|     | ");
            System.out.println("=====================================");
        }
        if (hp == 2) {
            System.out.println("   ____________");
            System.out.println("   |          _|_");
            System.out.println("   |         /   \\");
            System.out.println("   |        | * * |");
            System.out.println("   |         \\_ _/");
            System.out.println("   |           |");
            System.out.println("   |           |");
            System.out.println("   |");
            System.out.println("___|___");
            System.out.println("|     | ");
            System.out.println("=====================================");
        }
        if (hp == 3) {
            System.out.println("   ____________");
            System.out.println("   |          _|_");
            System.out.println("   |         /   \\");
            System.out.println("   |        | * - |");
            System.out.println("   |         \\_ _/");
            System.out.println("   |           |");
            System.out.println("   |           |");
            System.out.println("   |          / ");
            System.out.println("___|___      /   ");
            System.out.println("|     | ");
            System.out.println("=====================================");
        }
        if (hp == 4) {
            System.out.println("   ____________");
            System.out.println("   |          _|_");
            System.out.println("   |         /   \\");
            System.out.println("   |        | - - |");
            System.out.println("   |         \\_ _/");
            System.out.println("   |           |");
            System.out.println("   |           |");
            System.out.println("   |          / \\");
            System.out.println("___|___      /   \\ ");
            System.out.println("|     | ");
            System.out.println("=====================================");
        }
        if (hp == 5) {
            System.out.println("   ____________");
            System.out.println("   |          _|_");
            System.out.println("   |         /   \\");
            System.out.println("   |        | - x |");
            System.out.println("   |         \\_ _/");
            System.out.println("   |          _|");
            System.out.println("   |         / | ");
            System.out.println("   |          / \\ ");
            System.out.println("___|___      /   \\");
            System.out.println("|     | ");
            System.out.println("=====================================");
        }
        if (hp == 6) {
            System.out.println("   ____________");
            System.out.println("   |          _|_");
            System.out.println("   |         /   \\");
            System.out.println("   |        | x x |");
            System.out.println("   |         \\_ _/");
            System.out.println("   |          _|_");
            System.out.println("   |         / | \\");
            System.out.println("   |          / \\ ");
            System.out.println("___|___      /   \\");
            System.out.println("|     |            ");
            System.out.println("=====================================");
            System.out.println("=       💀   GAME OVER!   💀         =");
            System.out.println("=====================================");
        }
    }
    
    public static void prolouge() throws InterruptedException
    {
        clearScreen();
        System.out.println("======== 卂丂丂丨ム几爪乇几ㄒ ========");
        System.out.println("=   A man has been arregsted in   =");
        System.out.println("=           Ninjago city          =");
        System.out.println("===================================");
        delayDots(4);
        clearScreen();
        System.out.println("======== 卂丂丂丨ム几爪乇几ㄒ ========");
        System.out.println("=    Its up to you to save him    =");
        System.out.println("=     By solving Garmadan code    =");
        System.out.println("===================================");
        delayDots(4);
        clearScreen();
        System.out.println("======== 卂丂丂丨ム几爪乇几ㄒ ========");
        System.out.println("=            H   E   Y            =");
        System.out.println("===================================");
        delayDots(1);
    }
    
    
    public static void grave() throws InterruptedException
    {
        delayDots(4);
        clearScreen();
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("               _______");
        System.out.println("              /       \\");
        System.out.println("             /         \\");
        System.out.println("             | R. I. P |");
        System.out.println("             |  DAVE   |");
        System.out.println("             |         |            ");
        System.out.println("=====================================");
        System.out.println("=        💀   R.I.P DAVE   💀        =");
        System.out.println("=====================================");
    }
}
